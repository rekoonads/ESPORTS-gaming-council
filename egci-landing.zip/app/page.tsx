"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Users, Target, Gamepad2, Shield, Award, ArrowRight, Play, Star, Globe, Zap } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { PreRegisterForm } from "@/components/pre-register-form"

export default function EGCILanding() {
  const [isPreRegisterOpen, setIsPreRegisterOpen] = useState(false)

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center space-x-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-green-600">
              <Trophy className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                EGCI
              </h1>
              <p className="text-xs text-muted-foreground">Esports Gaming Council of India</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => scrollToSection("about")}
              className="text-sm font-medium hover:text-orange-600 transition-colors cursor-pointer"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection("initiatives")}
              className="text-sm font-medium hover:text-orange-600 transition-colors cursor-pointer"
            >
              Initiatives
            </button>
            <button
              onClick={() => scrollToSection("events")}
              className="text-sm font-medium hover:text-orange-600 transition-colors cursor-pointer"
            >
              Events
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-sm font-medium hover:text-orange-600 transition-colors cursor-pointer"
            >
              Contact
            </button>
          </nav>

          <Button className="bg-gradient-to-r from-orange-600 to-green-600 hover:from-orange-700 hover:to-green-700">
            Join EGCI
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-green-500/10" />
        <div className="container relative px-4 py-24 md:px-6 md:py-32">
          <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-6">
              <Badge className="bg-orange-500/20 text-orange-300 border-orange-500/30">
                Esports Gaming Council of India - Official Gaming Authority
              </Badge>
              <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl">
                Elevating{" "}
                <span className="bg-gradient-to-r from-orange-400 to-green-400 bg-clip-text text-transparent">
                  Indian Esports
                </span>
              </h1>
              <p className="text-xl text-gray-300 max-w-2xl">
                The Esports Gaming Council of India (EGCI) is the premier governing body dedicated to developing,
                regulating, and promoting competitive gaming across the nation. As India's official esports authority,
                we shape the future of competitive gaming.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-orange-600 to-green-600 hover:from-orange-700 hover:to-green-700"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Get Started
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10"
                  onClick={() => scrollToSection("about")}
                >
                  Learn More
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-orange-500 to-green-500 rounded-2xl blur-3xl opacity-30" />
              <Image
                src="/images/hero-gaming-setup.png"
                alt="Professional Esports Gaming Setup"
                width={600}
                height={500}
                className="relative rounded-2xl shadow-2xl object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Organization Introduction */}
      <section className="py-16 bg-gradient-to-r from-orange-50 to-green-50">
        <div className="container px-4 md:px-6 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
            Welcome to the{" "}
            <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
              Esports Gaming Council of India
            </span>
          </h2>
          <p className="text-lg text-gray-600 max-w-4xl mx-auto">
            Established as India's premier esports governing body, the Esports Gaming Council of India (EGCI) is
            committed to elevating competitive gaming standards, fostering talent development, and representing India's
            gaming community on the global stage.
          </p>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 scroll-mt-16">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-orange-100 text-orange-800 border-orange-200">About EGCI</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Governing the Future of{" "}
              <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                Indian Gaming
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The Esports Gaming Council of India (EGCI) serves as the official regulatory and developmental body for
              esports in India, fostering growth, ensuring fair play, and representing Indian gaming on the global
              stage.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Regulation & Standards</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Establishing comprehensive guidelines and standards for fair play, anti-doping measures, and ethical
                  gaming practices across all competitive levels.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Player Development</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Nurturing talent through training programs, mentorship initiatives, and providing pathways for
                  aspiring gamers to reach professional levels.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-lg flex items-center justify-center mb-4">
                  <Globe className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Global Representation</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base">
                  Representing India in international esports federations and ensuring Indian players compete at the
                  highest levels of global competition.
                </CardDescription>
              </CardContent>
            </Card>
          </div>

          {/* About Images Section */}
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">
                Building India's{" "}
                <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                  Esports Ecosystem
                </span>
              </h3>
              <p className="text-gray-600">
                From grassroots development to international championships, EGCI is committed to creating a
                comprehensive ecosystem that supports players, teams, and organizations at every level of competitive
                gaming.
              </p>
              <div className="flex items-center gap-4">
                <div className="flex -space-x-2">
                  <div className="w-8 h-8 bg-orange-500 rounded-full border-2 border-white"></div>
                  <div className="w-8 h-8 bg-green-500 rounded-full border-2 border-white"></div>
                  <div className="w-8 h-8 bg-purple-500 rounded-full border-2 border-white"></div>
                </div>
                <span className="text-sm text-gray-600">Trusted by thousands of gamers across India</span>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/images/gaming-team.png"
                alt="Indian Esports Team Celebrating Victory"
                width={500}
                height={400}
                className="rounded-2xl shadow-lg object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Initiatives Section */}
      <section id="initiatives" className="py-24 bg-gradient-to-br from-slate-50 to-gray-100 scroll-mt-16">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-green-100 text-green-800 border-green-200">Our Initiatives</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Driving Innovation in{" "}
              <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                Esports
              </span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="aspect-video relative mb-4">
                <Image
                  src="/images/tournament-arena.png"
                  alt="Tournament Arena"
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <Trophy className="h-8 w-8 text-orange-600 mb-2" />
                <CardTitle>National Championships</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Organizing premier national tournaments across multiple gaming titles with substantial prize pools and
                  international exposure opportunities.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="aspect-video relative mb-4">
                <Image
                  src="/images/gaming-academy.png"
                  alt="Gaming Academy"
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <Target className="h-8 w-8 text-green-600 mb-2" />
                <CardTitle>Grassroots Programs</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Building esports infrastructure at the grassroots level through school and college programs, local
                  tournaments, and community engagement.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
              <div className="aspect-video relative mb-4">
                <Image
                  src="/images/esports-certification.png"
                  alt="Esports Certification"
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <CardHeader>
                <Award className="h-8 w-8 text-purple-600 mb-2" />
                <CardTitle>Certification Programs</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Professional certification for coaches, referees, and tournament organizers to maintain high standards
                  across the ecosystem.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
              <CardHeader>
                <Gamepad2 className="h-8 w-8 text-blue-600 mb-2" />
                <CardTitle>Technology Innovation</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Investing in cutting-edge gaming technology, anti-cheat systems, and broadcast infrastructure for
                  world-class tournament experiences.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
              <CardHeader>
                <Star className="h-8 w-8 text-yellow-600 mb-2" />
                <CardTitle>Athlete Welfare</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Comprehensive support system including mental health resources, career guidance, and financial
                  assistance for professional gamers.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
              <CardHeader>
                <Zap className="h-8 w-8 text-red-600 mb-2" />
                <CardTitle>Industry Partnerships</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Strategic collaborations with gaming companies, sponsors, and educational institutions to create
                  sustainable career opportunities.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Upcoming Event Section */}
      <section
        id="events"
        className="py-24 bg-gradient-to-br from-orange-50 via-white to-green-50 relative overflow-hidden scroll-mt-16"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-orange-100/30 to-green-100/30" />
        <div className="container relative px-4 md:px-6">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-gradient-to-r from-orange-500 to-green-500 text-white border-0">
              Upcoming Event
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              India's Premier{" "}
              <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                Esports Gaming League
              </span>
            </h2>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="border-0 shadow-2xl overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-green-500/20" />
                <div className="relative p-8 md:p-12 text-center">
                  <div className="mb-6">
                    <Badge className="bg-yellow-500 text-black font-bold px-4 py-2 text-lg animate-pulse">
                      COMING SOON
                    </Badge>
                  </div>

                  <h3 className="text-3xl md:text-5xl font-bold text-white mb-4">EGCI Esports Gaming League</h3>

                  <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                    India's premier esports league, bringing together top players and teams across various gaming titles
                    for intense competition and national glory.
                  </p>

                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button
                      size="lg"
                      className="bg-gradient-to-r from-orange-600 to-green-600 hover:from-orange-700 hover:to-green-700"
                      onClick={() => setIsPreRegisterOpen(true)}
                    >
                      Pre-Register Now
                    </Button>
                    <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                      Get Notified
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            <div className="mt-12 grid md:grid-cols-4 gap-6">
              <Card className="bg-white/80 backdrop-blur border-orange-200 hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <Image
                    src="/images/mobile-gaming.png"
                    alt="BGMI Mobile Gaming"
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardContent className="p-6 text-center">
                  <Gamepad2 className="h-8 w-8 text-orange-600 mx-auto mb-3" />
                  <h4 className="font-semibold mb-2">BGMI</h4>
                  <p className="text-sm text-gray-600">Battle Royale Championship</p>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur border-green-200 hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <Image
                    src="/images/valorant-gameplay.png"
                    alt="Valorant Esports"
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardContent className="p-6 text-center">
                  <Target className="h-8 w-8 text-green-600 mx-auto mb-3" />
                  <h4 className="font-semibold mb-2">Valorant</h4>
                  <p className="text-sm text-gray-600">Tactical Shooter League</p>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur border-purple-200 hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <Image
                    src="/images/fifa-tournament.png"
                    alt="FIFA Esports Tournament"
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardContent className="p-6 text-center">
                  <Trophy className="h-8 w-8 text-purple-600 mx-auto mb-3" />
                  <h4 className="font-semibold mb-2">FIFA</h4>
                  <p className="text-sm text-gray-600">Football Simulation</p>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur border-blue-200 hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <Image
                    src="/images/gaming-technology.png"
                    alt="Gaming Technology"
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardContent className="p-6 text-center">
                  <Zap className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                  <h4 className="font-semibold mb-2">More</h4>
                  <p className="text-sm text-gray-600">Additional Titles</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/10 to-green-500/10" />
        <div className="container relative px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Join the{" "}
            <span className="bg-gradient-to-r from-orange-400 to-green-400 bg-clip-text text-transparent">
              Gaming Revolution?
            </span>
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Be part of India's esports journey. Whether you're a player, organizer, or enthusiast, EGCI provides the
            platform to excel and represent the nation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-orange-600 to-green-600 hover:from-orange-700 hover:to-green-700"
            >
              Register as Player
            </Button>
            <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10">
              Become a Partner
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gray-900 text-white py-16 scroll-mt-16">
        <div className="container px-4 md:px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-green-600">
                  <Trophy className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold bg-gradient-to-r from-orange-400 to-green-400 bg-clip-text text-transparent">
                    EGCI
                  </h3>
                  <p className="text-xs text-gray-400">Esports Gaming Council of India</p>
                </div>
              </div>
              <p className="text-gray-400">
                The Esports Gaming Council of India (EGCI) is the official governing body for esports in India,
                dedicated to developing and promoting competitive gaming nationwide.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button onClick={() => scrollToSection("about")} className="hover:text-orange-400 transition-colors">
                    About Us
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollToSection("events")} className="hover:text-orange-400 transition-colors">
                    Tournaments
                  </button>
                </li>
                <li>
                  <Link href="#" className="hover:text-orange-400 transition-colors">
                    Rankings
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-orange-400 transition-colors">
                    News
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">For Players</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <button onClick={() => setIsPreRegisterOpen(true)} className="hover:text-green-400 transition-colors">
                    Registration
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => scrollToSection("initiatives")}
                    className="hover:text-green-400 transition-colors"
                  >
                    Training Programs
                  </button>
                </li>
                <li>
                  <Link href="#" className="hover:text-green-400 transition-colors">
                    Certification
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-green-400 transition-colors">
                    Support
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@egci.in</li>
                <li>Phone: +91 11 4567 8900</li>
                <li>Address: New Delhi, India</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Esports Gaming Council of India. All rights reserved.</p>
          </div>
        </div>
      </footer>
      <PreRegisterForm isOpen={isPreRegisterOpen} onClose={() => setIsPreRegisterOpen(false)} />
    </div>
  )
}
