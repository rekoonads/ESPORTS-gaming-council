"use server"

import { z } from "zod"

const preRegisterSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  gamingHandle: z.string().min(2, "Gaming handle must be at least 2 characters"),
  preferredGame: z.string().min(1, "Please select a preferred game"),
  experience: z.string().min(1, "Please select your experience level"),
})

export async function preRegisterAction(formData: FormData) {
  try {
    // Simulate processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const data = {
      name: formData.get("name"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      gamingHandle: formData.get("gamingHandle"),
      preferredGame: formData.get("preferredGame"),
      experience: formData.get("experience"),
    }

    // Validate the data
    const validatedData = preRegisterSchema.parse(data)

    // Here you would typically save to a database
    // For now, we'll just simulate success
    console.log("Pre-registration data:", validatedData)

    return {
      success: true,
      message: `Thank you ${validatedData.name}! Your pre-registration has been submitted successfully. We'll notify you with updates about the EGCI Esports Gaming League.`,
    }
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        message: error.errors[0].message,
      }
    }

    return {
      success: false,
      message: "Something went wrong. Please try again.",
    }
  }
}
