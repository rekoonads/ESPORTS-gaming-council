"use client"
import { useActionState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { X, Gamepad2, Mail, Phone, User, Trophy } from "lucide-react"
import { preRegisterAction } from "@/app/actions/pre-register"

interface PreRegisterFormProps {
  isOpen: boolean
  onClose: () => void
}

export function PreRegisterForm({ isOpen, onClose }: PreRegisterFormProps) {
  const [state, action, isPending] = useActionState(preRegisterAction, null)

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="relative">
          <Button variant="ghost" size="icon" className="absolute right-2 top-2" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
          <div className="text-center">
            <Badge className="mb-4 bg-gradient-to-r from-orange-500 to-green-500 text-white">Pre-Registration</Badge>
            <CardTitle className="text-2xl mb-2">
              Join the{" "}
              <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                EGCI Esports Gaming League
              </span>
            </CardTitle>
            <CardDescription>Be among the first to register for India's premier esports gaming league</CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          {state?.success ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-green-600 mb-2">Registration Successful!</h3>
              <p className="text-gray-600 mb-6">{state.message}</p>
              <Button onClick={onClose} className="bg-gradient-to-r from-orange-600 to-green-600">
                Close
              </Button>
            </div>
          ) : (
            <form action={action} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Full Name
                  </Label>
                  <Input id="name" name="name" placeholder="Enter your full name" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email Address
                  </Label>
                  <Input id="email" name="email" type="email" placeholder="Enter your email" required />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Phone Number
                  </Label>
                  <Input id="phone" name="phone" placeholder="Enter your phone number" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gamingHandle" className="flex items-center gap-2">
                    <Gamepad2 className="h-4 w-4" />
                    Gaming Handle/IGN
                  </Label>
                  <Input id="gamingHandle" name="gamingHandle" placeholder="Your gaming username" required />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="preferredGame">Preferred Game</Label>
                  <Select name="preferredGame" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your main game" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bgmi">BGMI (Battlegrounds Mobile India)</SelectItem>
                      <SelectItem value="valorant">Valorant</SelectItem>
                      <SelectItem value="fifa">FIFA</SelectItem>
                      <SelectItem value="cod">Call of Duty Mobile</SelectItem>
                      <SelectItem value="freefire">Free Fire</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience">Experience Level</Label>
                  <Select name="experience" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner (0-1 years)</SelectItem>
                      <SelectItem value="intermediate">Intermediate (1-3 years)</SelectItem>
                      <SelectItem value="advanced">Advanced (3-5 years)</SelectItem>
                      <SelectItem value="professional">Professional (5+ years)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {state?.success === false && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-600 text-sm">{state.message}</p>
                </div>
              )}

              <div className="flex gap-4">
                <Button
                  type="submit"
                  disabled={isPending}
                  className="flex-1 bg-gradient-to-r from-orange-600 to-green-600 hover:from-orange-700 hover:to-green-700"
                >
                  {isPending ? "Submitting..." : "Pre-Register Now"}
                </Button>
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
